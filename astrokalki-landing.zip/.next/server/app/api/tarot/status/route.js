/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/tarot/status/route";
exports.ids = ["app/api/tarot/status/route"];
exports.modules = {

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Ftarot%2Fstatus%2Froute&page=%2Fapi%2Ftarot%2Fstatus%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftarot%2Fstatus%2Froute.ts&appDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Ftarot%2Fstatus%2Froute&page=%2Fapi%2Ftarot%2Fstatus%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftarot%2Fstatus%2Froute.ts&appDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   workAsyncStorage: () => (/* binding */ workAsyncStorage),\n/* harmony export */   workUnitAsyncStorage: () => (/* binding */ workUnitAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/route-kind */ \"(rsc)/./node_modules/next/dist/server/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _workspaces_v0_astrokalkilanding_final_3_src_app_api_tarot_status_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/tarot/status/route.ts */ \"(rsc)/./src/app/api/tarot/status/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/tarot/status/route\",\n        pathname: \"/api/tarot/status\",\n        filename: \"route\",\n        bundlePath: \"app/api/tarot/status/route\"\n    },\n    resolvedPagePath: \"/workspaces/v0-astrokalkilanding-final-3/src/app/api/tarot/status/route.ts\",\n    nextConfigOutput,\n    userland: _workspaces_v0_astrokalkilanding_final_3_src_app_api_tarot_status_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { workAsyncStorage, workUnitAsyncStorage, serverHooks } = routeModule;\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        workAsyncStorage,\n        workUnitAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIvaW5kZXguanM/bmFtZT1hcHAlMkZhcGklMkZ0YXJvdCUyRnN0YXR1cyUyRnJvdXRlJnBhZ2U9JTJGYXBpJTJGdGFyb3QlMkZzdGF0dXMlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZ0YXJvdCUyRnN0YXR1cyUyRnJvdXRlLnRzJmFwcERpcj0lMkZ3b3Jrc3BhY2VzJTJGdjAtYXN0cm9rYWxraWxhbmRpbmctZmluYWwtMyUyRnNyYyUyRmFwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9JTJGd29ya3NwYWNlcyUyRnYwLWFzdHJva2Fsa2lsYW5kaW5nLWZpbmFsLTMmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStGO0FBQ3ZDO0FBQ3FCO0FBQzBCO0FBQ3ZHO0FBQ0E7QUFDQTtBQUNBLHdCQUF3Qix5R0FBbUI7QUFDM0M7QUFDQSxjQUFjLGtFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxZQUFZO0FBQ1osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLFFBQVEsc0RBQXNEO0FBQzlEO0FBQ0EsV0FBVyw0RUFBVztBQUN0QjtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQzBGOztBQUUxRiIsInNvdXJjZXMiOlsiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IHBhdGNoRmV0Y2ggYXMgX3BhdGNoRmV0Y2ggfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9saWIvcGF0Y2gtZmV0Y2hcIjtcbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIvd29ya3NwYWNlcy92MC1hc3Ryb2thbGtpbGFuZGluZy1maW5hbC0zL3NyYy9hcHAvYXBpL3Rhcm90L3N0YXR1cy9yb3V0ZS50c1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvdGFyb3Qvc3RhdHVzL3JvdXRlXCIsXG4gICAgICAgIHBhdGhuYW1lOiBcIi9hcGkvdGFyb3Qvc3RhdHVzXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcInJvdXRlXCIsXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiYXBwL2FwaS90YXJvdC9zdGF0dXMvcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCIvd29ya3NwYWNlcy92MC1hc3Ryb2thbGtpbGFuZGluZy1maW5hbC0zL3NyYy9hcHAvYXBpL3Rhcm90L3N0YXR1cy9yb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHdvcmtBc3luY1N0b3JhZ2UsIHdvcmtVbml0QXN5bmNTdG9yYWdlLCBzZXJ2ZXJIb29rcyB9ID0gcm91dGVNb2R1bGU7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHdvcmtBc3luY1N0b3JhZ2UsXG4gICAgICAgIHdvcmtVbml0QXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgd29ya0FzeW5jU3RvcmFnZSwgd29ya1VuaXRBc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBwYXRjaEZldGNoLCAgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXBwLXJvdXRlLmpzLm1hcCJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Ftarot%2Fstatus%2Froute&page=%2Fapi%2Ftarot%2Fstatus%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftarot%2Fstatus%2Froute.ts&appDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "(rsc)/./src/app/api/tarot/status/route.ts":
/*!*******************************************!*\
  !*** ./src/app/api/tarot/status/route.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET)\n/* harmony export */ });\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\nconst DEFAULT_BASE = \"https://api.astrokalki.com\";\nasync function timedFetch(url, opts = {}, timeoutMs = 3000) {\n    const controller = new AbortController();\n    const id = setTimeout(()=>controller.abort(), timeoutMs);\n    const started = Date.now();\n    try {\n        const res = await fetch(url, {\n            ...opts,\n            headers: {\n                Accept: \"application/json\",\n                ...opts.headers || {}\n            },\n            cache: \"no-store\",\n            signal: controller.signal\n        });\n        const latencyMs = Date.now() - started;\n        clearTimeout(id);\n        return {\n            ok: res.ok,\n            status: res.status,\n            latencyMs,\n            res\n        };\n    } catch (e) {\n        const latencyMs = Date.now() - started;\n        clearTimeout(id);\n        const status = e?.name === \"AbortError\" ? \"timeout\" : \"network_error\";\n        return {\n            ok: false,\n            status,\n            latencyMs,\n            res: undefined\n        };\n    }\n}\nasync function GET(req) {\n    const { searchParams } = new URL(req.url);\n    const deep = searchParams.get(\"deep\") === \"1\";\n    const upstream = process.env.TAROT_API_BASE || DEFAULT_BASE;\n    // Fast health check\n    const base = upstream.replace(/\\/$/, \"\");\n    const healthCheck = await timedFetch(`${base}/index.php?route=health`, {}, 3000);\n    let cardsCheck;\n    let preview = {};\n    if (deep) {\n        const deepCheck = await timedFetch(`${base}/index.php?route=cards/onecard`, {}, 3000);\n        cardsCheck = {\n            ok: deepCheck.ok,\n            status: deepCheck.status,\n            latencyMs: deepCheck.latencyMs\n        };\n        if (deepCheck.ok && deepCheck.res) {\n            try {\n                const json = await deepCheck.res.json();\n                const data = json?.data ?? json;\n                preview = {\n                    name: data?.name,\n                    slug: data?.slug,\n                    image: data?.image || data?.image_url || undefined\n                };\n            } catch  {\n            // ignore JSON errors for preview\n            }\n        }\n    }\n    const body = {\n        upstream,\n        health: {\n            ok: healthCheck.ok,\n            status: healthCheck.status,\n            latencyMs: healthCheck.latencyMs\n        },\n        ...cardsCheck ? {\n            cards: cardsCheck\n        } : {},\n        preview,\n        timestamp: new Date().toISOString()\n    };\n    const statusCode = 200; // Always 200 with internal health details\n    return next_server__WEBPACK_IMPORTED_MODULE_0__.NextResponse.json(body, {\n        status: statusCode\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS90YXJvdC9zdGF0dXMvcm91dGUudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBd0Q7QUFFeEQsTUFBTUMsZUFBZTtBQUVyQixlQUFlQyxXQUFXQyxHQUFXLEVBQUVDLE9BQW9CLENBQUMsQ0FBQyxFQUFFQyxZQUFZLElBQUk7SUFDN0UsTUFBTUMsYUFBYSxJQUFJQztJQUN2QixNQUFNQyxLQUFLQyxXQUFXLElBQU1ILFdBQVdJLEtBQUssSUFBSUw7SUFDaEQsTUFBTU0sVUFBVUMsS0FBS0MsR0FBRztJQUN4QixJQUFJO1FBQ0YsTUFBTUMsTUFBTSxNQUFNQyxNQUFNWixLQUFLO1lBQzNCLEdBQUdDLElBQUk7WUFDUFksU0FBUztnQkFBRUMsUUFBUTtnQkFBb0IsR0FBSWIsS0FBS1ksT0FBTyxJQUFJLENBQUMsQ0FBQztZQUFFO1lBQy9ERSxPQUFPO1lBQ1BDLFFBQVFiLFdBQVdhLE1BQU07UUFDM0I7UUFDQSxNQUFNQyxZQUFZUixLQUFLQyxHQUFHLEtBQUtGO1FBQy9CVSxhQUFhYjtRQUNiLE9BQU87WUFBRWMsSUFBSVIsSUFBSVEsRUFBRTtZQUFFQyxRQUFRVCxJQUFJUyxNQUFNO1lBQUVIO1lBQVdOO1FBQUk7SUFDMUQsRUFBRSxPQUFPVSxHQUFRO1FBQ2YsTUFBTUosWUFBWVIsS0FBS0MsR0FBRyxLQUFLRjtRQUMvQlUsYUFBYWI7UUFDYixNQUFNZSxTQUFTQyxHQUFHQyxTQUFTLGVBQWUsWUFBWTtRQUN0RCxPQUFPO1lBQUVILElBQUk7WUFBT0M7WUFBUUg7WUFBV04sS0FBS1k7UUFBVTtJQUN4RDtBQUNGO0FBRU8sZUFBZUMsSUFBSUMsR0FBZ0I7SUFDeEMsTUFBTSxFQUFFQyxZQUFZLEVBQUUsR0FBRyxJQUFJQyxJQUFJRixJQUFJekIsR0FBRztJQUN4QyxNQUFNNEIsT0FBT0YsYUFBYUcsR0FBRyxDQUFDLFlBQVk7SUFDMUMsTUFBTUMsV0FBV0MsUUFBUUMsR0FBRyxDQUFDQyxjQUFjLElBQUluQztJQUUvQyxvQkFBb0I7SUFDcEIsTUFBTW9DLE9BQU9KLFNBQVNLLE9BQU8sQ0FBQyxPQUFPO0lBQ3JDLE1BQU1DLGNBQWMsTUFBTXJDLFdBQVcsR0FBR21DLEtBQUssdUJBQXVCLENBQUMsRUFBRSxDQUFDLEdBQUc7SUFFM0UsSUFBSUc7SUFDSixJQUFJQyxVQUE0RCxDQUFDO0lBRWpFLElBQUlWLE1BQU07UUFDUixNQUFNVyxZQUFZLE1BQU14QyxXQUFXLEdBQUdtQyxLQUFLLDhCQUE4QixDQUFDLEVBQUUsQ0FBQyxHQUFHO1FBQ2hGRyxhQUFhO1lBQUVsQixJQUFJb0IsVUFBVXBCLEVBQUU7WUFBRUMsUUFBUW1CLFVBQVVuQixNQUFNO1lBQUVILFdBQVdzQixVQUFVdEIsU0FBUztRQUFDO1FBQzFGLElBQUlzQixVQUFVcEIsRUFBRSxJQUFJb0IsVUFBVTVCLEdBQUcsRUFBRTtZQUNqQyxJQUFJO2dCQUNGLE1BQU02QixPQUFPLE1BQU1ELFVBQVU1QixHQUFHLENBQUM2QixJQUFJO2dCQUNyQyxNQUFNQyxPQUFPRCxNQUFNQyxRQUFRRDtnQkFDM0JGLFVBQVU7b0JBQ1JoQixNQUFNbUIsTUFBTW5CO29CQUNab0IsTUFBTUQsTUFBTUM7b0JBQ1pDLE9BQU9GLE1BQU1FLFNBQVNGLE1BQU1HLGFBQWFyQjtnQkFDM0M7WUFDRixFQUFFLE9BQU07WUFDTixpQ0FBaUM7WUFDbkM7UUFDRjtJQUNGO0lBRUEsTUFBTXNCLE9BQU87UUFDWGY7UUFDQWdCLFFBQVE7WUFDTjNCLElBQUlpQixZQUFZakIsRUFBRTtZQUNsQkMsUUFBUWdCLFlBQVloQixNQUFNO1lBQzFCSCxXQUFXbUIsWUFBWW5CLFNBQVM7UUFDbEM7UUFDQSxHQUFJb0IsYUFBYTtZQUFFVSxPQUFPVjtRQUFXLElBQUksQ0FBQyxDQUFDO1FBQzNDQztRQUNBVSxXQUFXLElBQUl2QyxPQUFPd0MsV0FBVztJQUNuQztJQUVBLE1BQU1DLGFBQWEsS0FBSywwQ0FBMEM7SUFDbEUsT0FBT3JELHFEQUFZQSxDQUFDMkMsSUFBSSxDQUFDSyxNQUFNO1FBQUV6QixRQUFROEI7SUFBVztBQUN0RCIsInNvdXJjZXMiOlsiL3dvcmtzcGFjZXMvdjAtYXN0cm9rYWxraWxhbmRpbmctZmluYWwtMy9zcmMvYXBwL2FwaS90YXJvdC9zdGF0dXMvcm91dGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmV4dFJlcXVlc3QsIE5leHRSZXNwb25zZSB9IGZyb20gXCJuZXh0L3NlcnZlclwiO1xuXG5jb25zdCBERUZBVUxUX0JBU0UgPSBcImh0dHBzOi8vYXBpLmFzdHJva2Fsa2kuY29tXCI7XG5cbmFzeW5jIGZ1bmN0aW9uIHRpbWVkRmV0Y2godXJsOiBzdHJpbmcsIG9wdHM6IFJlcXVlc3RJbml0ID0ge30sIHRpbWVvdXRNcyA9IDMwMDApIHtcbiAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgY29uc3QgaWQgPSBzZXRUaW1lb3V0KCgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSwgdGltZW91dE1zKTtcbiAgY29uc3Qgc3RhcnRlZCA9IERhdGUubm93KCk7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAuLi5vcHRzLFxuICAgICAgaGVhZGVyczogeyBBY2NlcHQ6IFwiYXBwbGljYXRpb24vanNvblwiLCAuLi4ob3B0cy5oZWFkZXJzIHx8IHt9KSB9LFxuICAgICAgY2FjaGU6IFwibm8tc3RvcmVcIixcbiAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgfSk7XG4gICAgY29uc3QgbGF0ZW5jeU1zID0gRGF0ZS5ub3coKSAtIHN0YXJ0ZWQ7XG4gICAgY2xlYXJUaW1lb3V0KGlkKTtcbiAgICByZXR1cm4geyBvazogcmVzLm9rLCBzdGF0dXM6IHJlcy5zdGF0dXMsIGxhdGVuY3lNcywgcmVzIH0gYXMgY29uc3Q7XG4gIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgIGNvbnN0IGxhdGVuY3lNcyA9IERhdGUubm93KCkgLSBzdGFydGVkO1xuICAgIGNsZWFyVGltZW91dChpZCk7XG4gICAgY29uc3Qgc3RhdHVzID0gZT8ubmFtZSA9PT0gXCJBYm9ydEVycm9yXCIgPyBcInRpbWVvdXRcIiA6IFwibmV0d29ya19lcnJvclwiO1xuICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzLCBsYXRlbmN5TXMsIHJlczogdW5kZWZpbmVkIH0gYXMgY29uc3Q7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVChyZXE6IE5leHRSZXF1ZXN0KSB7XG4gIGNvbnN0IHsgc2VhcmNoUGFyYW1zIH0gPSBuZXcgVVJMKHJlcS51cmwpO1xuICBjb25zdCBkZWVwID0gc2VhcmNoUGFyYW1zLmdldChcImRlZXBcIikgPT09IFwiMVwiO1xuICBjb25zdCB1cHN0cmVhbSA9IHByb2Nlc3MuZW52LlRBUk9UX0FQSV9CQVNFIHx8IERFRkFVTFRfQkFTRTtcblxuICAvLyBGYXN0IGhlYWx0aCBjaGVja1xuICBjb25zdCBiYXNlID0gdXBzdHJlYW0ucmVwbGFjZSgvXFwvJC8sIFwiXCIpO1xuICBjb25zdCBoZWFsdGhDaGVjayA9IGF3YWl0IHRpbWVkRmV0Y2goYCR7YmFzZX0vaW5kZXgucGhwP3JvdXRlPWhlYWx0aGAsIHt9LCAzMDAwKTtcblxuICBsZXQgY2FyZHNDaGVjazogeyBvazogYm9vbGVhbjsgc3RhdHVzOiBudW1iZXIgfCBzdHJpbmc7IGxhdGVuY3lNczogbnVtYmVyIH0gfCB1bmRlZmluZWQ7XG4gIGxldCBwcmV2aWV3OiB7IG5hbWU/OiBzdHJpbmc7IHNsdWc/OiBzdHJpbmc7IGltYWdlPzogc3RyaW5nIH0gPSB7fTtcblxuICBpZiAoZGVlcCkge1xuICAgIGNvbnN0IGRlZXBDaGVjayA9IGF3YWl0IHRpbWVkRmV0Y2goYCR7YmFzZX0vaW5kZXgucGhwP3JvdXRlPWNhcmRzL29uZWNhcmRgLCB7fSwgMzAwMCk7XG4gICAgY2FyZHNDaGVjayA9IHsgb2s6IGRlZXBDaGVjay5vaywgc3RhdHVzOiBkZWVwQ2hlY2suc3RhdHVzLCBsYXRlbmN5TXM6IGRlZXBDaGVjay5sYXRlbmN5TXMgfTtcbiAgICBpZiAoZGVlcENoZWNrLm9rICYmIGRlZXBDaGVjay5yZXMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGpzb24gPSBhd2FpdCBkZWVwQ2hlY2sucmVzLmpzb24oKTtcbiAgICAgICAgY29uc3QgZGF0YSA9IGpzb24/LmRhdGEgPz8ganNvbjtcbiAgICAgICAgcHJldmlldyA9IHtcbiAgICAgICAgICBuYW1lOiBkYXRhPy5uYW1lLFxuICAgICAgICAgIHNsdWc6IGRhdGE/LnNsdWcsXG4gICAgICAgICAgaW1hZ2U6IGRhdGE/LmltYWdlIHx8IGRhdGE/LmltYWdlX3VybCB8fCB1bmRlZmluZWQsXG4gICAgICAgIH07XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gaWdub3JlIEpTT04gZXJyb3JzIGZvciBwcmV2aWV3XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgY29uc3QgYm9keSA9IHtcbiAgICB1cHN0cmVhbSxcbiAgICBoZWFsdGg6IHtcbiAgICAgIG9rOiBoZWFsdGhDaGVjay5vayxcbiAgICAgIHN0YXR1czogaGVhbHRoQ2hlY2suc3RhdHVzLFxuICAgICAgbGF0ZW5jeU1zOiBoZWFsdGhDaGVjay5sYXRlbmN5TXMsXG4gICAgfSxcbiAgICAuLi4oY2FyZHNDaGVjayA/IHsgY2FyZHM6IGNhcmRzQ2hlY2sgfSA6IHt9KSxcbiAgICBwcmV2aWV3LFxuICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICB9O1xuXG4gIGNvbnN0IHN0YXR1c0NvZGUgPSAyMDA7IC8vIEFsd2F5cyAyMDAgd2l0aCBpbnRlcm5hbCBoZWFsdGggZGV0YWlsc1xuICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oYm9keSwgeyBzdGF0dXM6IHN0YXR1c0NvZGUgfSk7XG59Il0sIm5hbWVzIjpbIk5leHRSZXNwb25zZSIsIkRFRkFVTFRfQkFTRSIsInRpbWVkRmV0Y2giLCJ1cmwiLCJvcHRzIiwidGltZW91dE1zIiwiY29udHJvbGxlciIsIkFib3J0Q29udHJvbGxlciIsImlkIiwic2V0VGltZW91dCIsImFib3J0Iiwic3RhcnRlZCIsIkRhdGUiLCJub3ciLCJyZXMiLCJmZXRjaCIsImhlYWRlcnMiLCJBY2NlcHQiLCJjYWNoZSIsInNpZ25hbCIsImxhdGVuY3lNcyIsImNsZWFyVGltZW91dCIsIm9rIiwic3RhdHVzIiwiZSIsIm5hbWUiLCJ1bmRlZmluZWQiLCJHRVQiLCJyZXEiLCJzZWFyY2hQYXJhbXMiLCJVUkwiLCJkZWVwIiwiZ2V0IiwidXBzdHJlYW0iLCJwcm9jZXNzIiwiZW52IiwiVEFST1RfQVBJX0JBU0UiLCJiYXNlIiwicmVwbGFjZSIsImhlYWx0aENoZWNrIiwiY2FyZHNDaGVjayIsInByZXZpZXciLCJkZWVwQ2hlY2siLCJqc29uIiwiZGF0YSIsInNsdWciLCJpbWFnZSIsImltYWdlX3VybCIsImJvZHkiLCJoZWFsdGgiLCJjYXJkcyIsInRpbWVzdGFtcCIsInRvSVNPU3RyaW5nIiwic3RhdHVzQ29kZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/tarot/status/route.ts\n");

/***/ }),

/***/ "(ssr)/./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true!":
/*!******************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-flight-client-entry-loader.js?server=true! ***!
  \******************************************************************************************************/
/***/ (() => {



/***/ }),

/***/ "../app-render/after-task-async-storage.external":
/*!***********************************************************************************!*\
  !*** external "next/dist/server/app-render/after-task-async-storage.external.js" ***!
  \***********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/after-task-async-storage.external.js");

/***/ }),

/***/ "../app-render/work-async-storage.external":
/*!*****************************************************************************!*\
  !*** external "next/dist/server/app-render/work-async-storage.external.js" ***!
  \*****************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-async-storage.external.js");

/***/ }),

/***/ "./work-unit-async-storage.external":
/*!**********************************************************************************!*\
  !*** external "next/dist/server/app-render/work-unit-async-storage.external.js" ***!
  \**********************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/work-unit-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader/index.js?name=app%2Fapi%2Ftarot%2Fstatus%2Froute&page=%2Fapi%2Ftarot%2Fstatus%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftarot%2Fstatus%2Froute.ts&appDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3%2Fsrc%2Fapp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=%2Fworkspaces%2Fv0-astrokalkilanding-final-3&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();